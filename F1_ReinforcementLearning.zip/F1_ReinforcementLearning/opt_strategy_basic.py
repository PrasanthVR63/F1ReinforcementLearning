import numpy as np
import pyomo.environ as pyo

def opt_strategy_basic(tot_no_laps: int, tire_pars: dict, tires: list) -> np.ndarray:
    # Extract tire degradation coefficients
    k_1_lin_array = np.array([tire_pars[x[0]]['k_1_lin'] for x in tires])
    k_0_array = np.array([tire_pars[x[0]]['k_0'] for x in tires])
    age_array = np.array([x[1] for x in tires])

    # Number of stints
    no_stints = len(tires)

    # Setup problem matrices
    P = np.eye(no_stints) * 0.5 * k_1_lin_array * 2  # * 2 because of standard form
    q = (0.5 + age_array) * k_1_lin_array + k_0_array

    # Create a model
    model = pyo.ConcreteModel()

    # Define the variables
    model.stints = pyo.RangeSet(no_stints)
    model.x = pyo.Var(model.stints, within=pyo.Integers, bounds=(1, tot_no_laps))

    # Define the objective
    def objective_rule(m):
        return sum(P[i-1, i-1] * m.x[i] * m.x[i] + q[i-1] * m.x[i] for i in m.stints)

    model.obj = pyo.Objective(rule=objective_rule, sense=pyo.minimize)

    # Define the constraints
    def sum_constraint_rule(m):
        return sum(m.x[i] for i in m.stints) == tot_no_laps

    model.sum_constraint = pyo.Constraint(rule=sum_constraint_rule)

    # Solve
    solver = pyo.SolverFactory('glpk')
    result = solver.solve(model)

    # Check if the solution exists and return
    if result.solver.status == pyo.SolverStatus.ok:
        stint_lengths = np.array([model.x[i].value for i in model.stints], dtype=np.int32)
    else:
        stint_lengths = None

    return stint_lengths
