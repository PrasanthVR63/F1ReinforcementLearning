import os
from flask import Flask, request, jsonify

import sys
sys.path.append("/home/prashenv/Desktop/Main_Dissertation/race-simulation/machine_learning_rl_training/src/")

import numpy as np

from rl_environment_single_agent import RaceSimulation
import uuid

app = Flask(__name__)

# Store instances of environments with their session IDs
ENVIRONMENTS = {}

MCS_PARS_FILE = '/home/prashenv/Desktop/Main_Dissertation/race-simulation/racesim/input/parameters/pars_mcs.ini'

@app.route('/create_env', methods=['POST'])
def create_env():
    race = request.json.get('race', "Shanghai_2019")
    RACE_PARS_FILE = os.path.join('/home/prashenv/Desktop/Main_Dissertation/race-simulation/racesim/input/parameters', f'pars_{race}.ini')

    # Initialize environment
    env = RaceSimulation(RACE_PARS_FILE, MCS_PARS_FILE, use_prob_infl=True, create_rand_events=True)
    
    # Create a unique session ID for this environment
    session_id = str(uuid.uuid4())
    
    ENVIRONMENTS[session_id] = {
        "env": env,
        "RACE_PARS_FILE": RACE_PARS_FILE,
        "MCS_PARS_FILE": MCS_PARS_FILE
    }

    return jsonify({"message": "Environment created successfully.", "session_id": session_id})

@app.route('/<session_id>/reset', methods=['POST'])
def reset(session_id):
    env_data = ENVIRONMENTS.get(session_id)
    if not env_data:
        return jsonify({"error": "Environment not found"}), 404
    env = env_data["env"]
    time_step = env.reset()._asdict()
    
    # Convert ndarray to list for JSON serialization
    for key, value in time_step.items():
        if isinstance(value, np.ndarray):
            time_step[key] = value.tolist()
    
    return jsonify(time_step)

from tf_agents.trajectories import time_step as ts

@app.route('/<session_id>/step', methods=['POST'])
def step(session_id):
    action = request.json.get('action')
    env_data = ENVIRONMENTS.get(session_id)
    
    if not env_data:
        return jsonify({"error": "Environment not found"}), 404
    env = env_data["env"]
    
    if action is None:
        return jsonify({"error": "Action not provided"}), 400
    
    time_step = env.step(action)
    
    # Convert time_step to dictionary and add done information
    response_data = numpy_to_list(time_step._asdict())
    response_data['done'] = bool(time_step.step_type == ts.StepType.LAST)
    
    print(jsonify(response_data))
    return jsonify(response_data)



@app.route('/<session_id>/current_time_step', methods=['GET'])
def current_time_step(session_id):
    env_data = ENVIRONMENTS.get(session_id)
    
    if not env_data:
        return jsonify({"error": "Environment not found"}), 404
    env = env_data["env"]
    
    time_step = env.current_time_step()
    return jsonify(time_step._asdict())

@app.route('/action_spec', methods=['GET'])
def action_spec():
    session_id = request.args.get('session_id')
    env_data = ENVIRONMENTS.get(session_id)
    if not env_data:
        return jsonify({"error": "Invalid session ID"}), 400
    env = env_data["env"]
    spec = env.action_spec()
    return jsonify(str(spec))

@app.route('/observation_spec', methods=['GET'])
def observation_spec():
    session_id = request.args.get('session_id')
    env_data = ENVIRONMENTS.get(session_id)
    if not env_data:
        return jsonify({"error": "Invalid session ID"}), 400
    env = env_data["env"]
    spec = env.time_step_spec().observation
    return jsonify(str(spec))



def numpy_to_list(data):
    if isinstance(data, dict):
        return {key: numpy_to_list(value) for key, value in data.items()}
    elif isinstance(data, np.ndarray):
        return data.tolist()
    elif isinstance(data, list):
        return [numpy_to_list(item) for item in data]
    else:
        return data

if __name__ == '__main__':
    app.run(debug=True)
